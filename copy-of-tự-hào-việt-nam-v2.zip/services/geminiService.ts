import { GoogleGenAI, Modality, GenerateContentResponse, Part } from "@google/genai";

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = (error) => reject(error);
    });
};

export const generateImage = async (
    imageFile: File,
    prompt: string
): Promise<string> => {
    // API KEY is read from environment variables
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

    try {
        const base64ImageData = await fileToBase64(imageFile);

        const imagePart = {
            inlineData: {
                data: base64ImageData,
                mimeType: imageFile.type,
            },
        };

        const textPart = {
            text: prompt,
        };

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [imagePart, textPart],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const imagePartResponse = response.candidates?.[0]?.content?.parts.find(
            (part: Part) => part.inlineData
        );
        
        if (imagePartResponse && imagePartResponse.inlineData) {
            const base64ImageBytes = imagePartResponse.inlineData.data;
            const mimeType = imagePartResponse.inlineData.mimeType;
            return `data:${mimeType};base64,${base64ImageBytes}`;
        } else {
            const textResponse = response.text?.trim();
            if (textResponse) {
                throw new Error(`API did not return an image. Response: ${textResponse}`);
            }
            throw new Error('Image generation failed: No image data received from the API.');
        }
    } catch (error) {
        console.error('Error generating image:', error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate image: ${error.message}`);
        }
        throw new Error('An unknown error occurred during image generation.');
    }
};
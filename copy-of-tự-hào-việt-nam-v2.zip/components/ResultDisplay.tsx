import React from 'react';
import type { GenerationResults } from '../types';

const DownloadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);

const ResultCardLoader: React.FC<{ themeName: string }> = ({ themeName }) => (
    <div className="w-full aspect-square bg-gray-100 dark:bg-gray-800 rounded-lg flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 dark:border-gray-600">
        <div className="w-8 h-8 border-2 border-dashed rounded-full animate-spin border-yellow-400 mb-3"></div>
        <p className="text-sm font-semibold text-center text-gray-600 dark:text-gray-300">{themeName}</p>
        <p className="text-xs text-center text-gray-400">Đang tạo...</p>
    </div>
);

const ResultCardError: React.FC<{ themeName: string; error: string }> = ({ themeName, error }) => (
    <div className="w-full aspect-square bg-red-50 dark:bg-red-900/30 rounded-lg flex flex-col items-center justify-center p-4 border-2 border-red-400">
        <p className="text-sm font-bold text-center text-red-700 dark:text-red-300">{themeName}</p>
        <p className="text-xs text-center text-red-500 dark:text-red-400 mt-2">{error}</p>
    </div>
);

const ResultCardSuccess: React.FC<{ themeName: string; imageUrl: string }> = ({ themeName, imageUrl }) => (
    <div className="w-full group">
        <div className="w-full aspect-square bg-black rounded-lg overflow-hidden relative">
            <img src={imageUrl} alt={themeName} className="w-full h-full object-contain" />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-4">
                <p className="text-white font-bold text-center mb-4">{themeName}</p>
                <a
                    href={imageUrl}
                    download={`${themeName.replace(/\s/g, '-')}.png`}
                    className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-black bg-yellow-400 hover:bg-yellow-500 transition-all duration-200 transform hover:scale-110"
                >
                    <DownloadIcon />
                    Tải về
                </a>
            </div>
        </div>
    </div>
);


interface ResultDisplayProps {
    generationResults: GenerationResults;
    onReset: () => void;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ generationResults, onReset }) => {
    const resultIds = Object.keys(generationResults);

    if (resultIds.length === 0) {
        return (
            <div className="w-full flex flex-col items-center justify-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-inner h-full min-h-[400px] text-center">
                <h2 className="text-2xl font-bold mb-4 text-red-700 dark:text-red-500">Kết quả sẽ hiển thị ở đây</h2>
                <p className="text-gray-500 dark:text-gray-400">Hãy tải ảnh, chọn tối đa 5 chủ đề và bắt đầu phép màu!</p>
            </div>
        );
    }

    return (
        <div className="w-full flex flex-col items-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
            <div className="w-full flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-red-700 dark:text-red-500">Tác phẩm của bạn!</h2>
                <button
                    onClick={onReset}
                    className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 transition-colors"
                >
                    Thử lại từ đầu
                </button>
            </div>
            <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-4">
                {resultIds.map((id) => {
                    const result = generationResults[id];
                    let card;
                    switch (result.status) {
                        case 'loading':
                            card = <ResultCardLoader themeName={result.themeName} />;
                            break;
                        case 'done':
                            card = <ResultCardSuccess themeName={result.themeName} imageUrl={result.imageUrl!} />;
                            break;
                        case 'error':
                             card = <ResultCardError themeName={result.themeName} error={result.error!} />;
                             break;
                        default:
                            return null;
                    }
                    return <div key={id} className="animate-fade-in">{card}</div>;
                })}
            </div>
        </div>
    );
};

export default ResultDisplay;
import React, { useRef, useCallback } from 'react';

interface ImageUploaderProps {
    onImageUpload: (file: File) => void;
    imagePreviewUrl: string | null;
}

const UploadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
    </svg>
);

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, imagePreviewUrl }) => {
    const inputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            onImageUpload(event.target.files[0]);
        }
    };

    const handleClick = () => {
        inputRef.current?.click();
    };

    const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
        if (event.dataTransfer.files && event.dataTransfer.files[0]) {
            onImageUpload(event.dataTransfer.files[0]);
        }
    }, [onImageUpload]);

    const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
    };


    return (
        <div className="w-full">
            <h2 className="text-xl font-bold mb-4 text-center text-red-700 dark:text-red-500">Bước 1: Tải ảnh của bạn lên</h2>
            <div
                className="w-full h-64 border-4 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center cursor-pointer hover:border-red-500 dark:hover:border-red-500 transition-colors bg-white dark:bg-gray-800 relative"
                onClick={handleClick}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
            >
                <input
                    type="file"
                    ref={inputRef}
                    onChange={handleFileChange}
                    accept="image/png, image/jpeg, image/webp"
                    className="hidden"
                />
                {imagePreviewUrl ? (
                    <img src={imagePreviewUrl} alt="Preview" className="w-full h-full object-contain p-2 rounded-md" />
                ) : (
                    <div className="text-center">
                        <UploadIcon />
                        <p className="mt-2 text-gray-500 dark:text-gray-400">Kéo & thả hoặc nhấn để chọn ảnh</p>
                        <p className="text-xs text-gray-400">PNG, JPG, WEBP</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ImageUploader;
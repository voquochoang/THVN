import React, { useState, useEffect } from 'react';

const loadingMessages = [
    "AI đang lấy cảm hứng từ vẻ đẹp Việt Nam...",
    "Đang phác họa những đường nét đầu tiên...",
    "Thêm màu cờ đỏ sao vàng...",
    "Tinh chỉnh chi tiết cho thật sống động...",
    "Sắp hoàn thành kiệt tác rồi!",
];

const Loader: React.FC = () => {
    const [messageIndex, setMessageIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setMessageIndex((prevIndex) => (prevIndex + 1) % loadingMessages.length);
        }, 2500);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex flex-col items-center justify-center z-50 backdrop-blur-sm">
            <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-yellow-400"></div>
            <p className="text-white text-lg mt-4 font-semibold px-4 text-center">{loadingMessages[messageIndex]}</p>
        </div>
    );
};

export default Loader;
